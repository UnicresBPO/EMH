app.component('appSlideshow', {
    templateUrl: 'components/app-slideshow/app-slideshow.component.html',
    controller: ['$scope' ,function ($scope) {
        this.$onInit = function () {
        };

        this.$onDestroy = function () {

        };
    }],
    controllerAs: 'vm',
    bindings: {}
});