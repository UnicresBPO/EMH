app.component('appMenuMega', {
    templateUrl: 'components/app-menu-mega/app-menu-mega.component.html',
    controller: ['$scope' ,function ($scope) {
        this.$onInit = function () {
        };

        this.$onDestroy = function () {

        };
    }],
    controllerAs: 'vm',
    bindings: {}
});