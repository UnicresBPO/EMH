app.component('appFooter', {
    templateUrl: 'components/app-footer/app-footer.component.html',
    controller: ['$scope', function ($scope) {
        this.$onInit = function () {
        };

        this.$onDestroy = function () {

        };
    }],
    controllerAs: 'vm',
    bindings: {}
});