var app = angular.module('BlankApp',
    ['ui.router', 'ngMaterial', 'angular-loading-bar', 'restangular', 'ngStorage','satellizer', 'ngMessages', 'ngAria', 'ngAnimate',
    'ngScrollbars','slick', 'afkl.lazyImage','ngPassword','sasrio.angular-material-sidenav', 'md.data.table', 'ngSanitize']);