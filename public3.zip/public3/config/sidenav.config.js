app.config(function (ssSideNavSectionsProvider, $mdThemingProvider) {
    ssSideNavSectionsProvider.initWithTheme($mdThemingProvider);
    ssSideNavSectionsProvider.initWithSections([]);
});